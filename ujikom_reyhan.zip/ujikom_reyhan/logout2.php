<?php 
// mengaktifkan session php
session_start();
unset($_SESSION['nama']);
// menghapus semua session
session_destroy();
 
// mengalihkan halaman ke halaman login
header("location:index2.php");
?>
